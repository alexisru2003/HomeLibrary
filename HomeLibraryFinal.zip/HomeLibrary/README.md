Home Library
This is a library application which allows a user to login and is can perform the following actions:
View available books
View different book categories
Add a new book
Edit already existing book
Add to cart and view items in the cart
The site also has a registration page for the new users.