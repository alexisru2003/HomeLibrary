package com.home.library;

import org.junit.jupiter.api.Test;

class HomeLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
