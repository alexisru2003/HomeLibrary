package com.home.library.form;

import javax.validation.constraints.NotEmpty;

public class EditBookForm {

    @NotEmpty(message = "Field cannot be empty")
    private String id;

    @NotEmpty(message = "Field cannot be empty")
    private String bookName;

    @NotEmpty(message = "Field cannot be empty")
    private String author;

    @NotEmpty(message = "Field cannot be empty")
    private String quantity;

    @NotEmpty(message = "Field cannot be empty")
    private String price;

    @NotEmpty(message = "Field cannot be empty")
    private String category;

    @NotEmpty(message = "Field cannot be empty")
    private String crossPrice;

    @NotEmpty(message = "Field cannot be empty")
    private String type;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCrossPrice() {
        return crossPrice;
    }

    public void setCrossPrice(String crossPrice) {
        this.crossPrice = crossPrice;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
